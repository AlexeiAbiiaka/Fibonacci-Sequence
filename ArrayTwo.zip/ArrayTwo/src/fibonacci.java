
// **********************************************************************
// Programmer:	Alexei Abiiaka
// Class:		CS30S
//
// Assignment:	Fibonacci Sequence
//
// Description:	This sequence adds the first two numbers infront a nnumber to make it.
//
//
//	Input:		describe any input from keyboard or file
//
//  Output:		describe the result of your program
// ***********************************************************************

import javax.swing.*;
import java.text.DecimalFormat;

public class fibonacci
{  // begin class
	public static void main(String args[])
	{  // begin main
	// ***** declaration of constants *****
		
	// ***** declaration of variables *****
		
	
	// ***** create objects *****
		
		
		
	// ***** create input stream *****
		
	
		//ConsoleReader console = new ConsoleReader(System.in);
		
	// ***** Print Banner *****
		Banner banner = new Banner("Array Excercise 1");
		banner.printBanner("Making Fibonacci Sequence");
		
	// ***** get input *****
	
		// all input is gathered in this section
		// remember to put ConsoleReader.class into the
		// same folder.
	
	// ***** processing *****
		
	int[] fibonacciArray = new int[20];
	fibonacciArray[0] = 0;
	fibonacciArray[1] = 1;
	for (int i = 2; i < 20; i++) {
		fibonacciArray[i] =  fibonacciArray[i-2] + fibonacciArray[i-1];
		System.out.println(fibonacciArray[i]);
	}
		
		
		
	// ***** output *****
	
	
		// all formatted ouput is printed in this section

	// ***** closing message *****
	
		System.out.println("end of processing");
	
	}  // end main	
}  // end class