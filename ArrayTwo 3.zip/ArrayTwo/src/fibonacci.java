
// **********************************************************************
// Programmer:	Alexei Abiiaka
// Class:		CS30S
//
// Assignment:	Fibonacci Sequence
//
// Description:	This sequence adds the first two numbers infront a nnumber to make it.
//
//
//	Input:		describe any input from keyboard or file
//
//  Output:		describe the result of your program
// ***********************************************************************

import javax.swing.*;
import java.text.DecimalFormat;

public class fibonacci
{  // begin class
	public static void main(String args[])
	{  // begin main
	// ***** declaration of constants *****
		
	// ***** declaration of variables *****
		String str1 ="";
		String str2 ="";
		String strall = "";
	// ***** create objects *****

	// ***** create input stream *****
		
	// ***** Print Banner *****
		Banner banner = new Banner("Array Excercise 1");
		banner.printBanner("Making Fibonacci Sequence");
		
	// ***** get input *****
	
	// ***** processing *****
		
	int[] fibonacciArray = new int[100];
	fibonacciArray[0] = 0;
	fibonacciArray[1] = 1;
	for (int i = 2; i < 100; i++) {
		fibonacciArray[i] =  fibonacciArray[i-2] + fibonacciArray[i-1];
		System.out.println(fibonacciArray[i]);
	}
		
			
	// ***** output *****
	//Shows the first five numbers and last five
/**
	System.out.println("First Five");
	for (int i = 0; i < 5; i++) {
	  str1+=fibonacciArray[i];
	  str1+=",";
	  if(i==2) {str1+="\n\r";}
	}
	strall="First Five; \n\r";
	strall+=str1;
	System.out.println(str1);
	
	
	System.out.println("Last Five");
	for (int i = 20 -1; i > 14; i--) {
	  str2+=fibonacciArray[i];
	  str2+=",";
	  if(i==17) {str2+="\n\r";}
	}
	strall+="\nLast Five; \n\r";
	strall+=str2;
	System.out.println(str2);
*/	

	// ***** closing message *****
	
	JOptionPane.showMessageDialog(null, strall);
	banner.endOfProcessing();
	
	}  // end main	
	public static int output(String prompt) {
		return new Integer(JOptionPane.showInputDialog(prompt));
	}
	
}  // end class







